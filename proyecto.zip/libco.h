// libco.h
#ifndef LIBCO_H
#define LIBCO_H

// Declaración de la función para insertar datos en la base de datos
void insert_to_db(const char *query);

#endif

